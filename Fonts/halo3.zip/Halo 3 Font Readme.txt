********************************************************************
*                           HALO 3 FONT                            *
*          In homage of Xbox's Halo created by Bungie              *
*                                                                  *
*                     Created by Will Turnbow                      *
*                    willyliliana@sbcglobal.net                    *
*                      www.willyliliana.com                        *
********************************************************************

Finally an update of the Halo font.  It's been updated to match the
logos of Halo 2, Halo 3, Halo Wars and the Halo 2 ad run before
release.  I've also revised some letters and numbers I never liked.
If you have any problems with the font, email me or try my website.

Obviously the font is free.  Please do whatever you want with it.
If you like it or find a problem with it drop me a line.  If you
would like something added please ask though I think I have most of
it this time.


Characters: 	A-Z
		a-z
		0-9
		Common Puncutation
		
Extras:
		Bullet - Alt249
		Ellipsis - Alt0133
		QuoteL - Alt0145
		QuoteR - Alt0146
		QuoteDBLL - Alt0147
		QuoteDBLR - Alt0148
		Enddash - Alt0150
		Emdash - Alt0151
		Trademark - Alt0153
		Cent - Alt0162
		BrokenBar - Alt0166
		Copyright - Alt0169
		Minus - Alt0173
		Registered - Alt0174
		Degree - Alt0176
		Plusminus - Alt0177
		Twosuper - Alt0178
		Threesuper - Alt0179
		Acute - Alt0180
		Periodcenter - Alt0183
		Cedilla - Alt0184
		Onesuper - Alt0185
		Onequater - Alt0188
		Onehalf - Alt0189
		Threequarter - Alt0190
		Multiply - Alt0215
		Divide - Alt0247


How to use in Windows:

First unzip the font into a folder that you can find again (like C:\temp).  Now go to Control Panel, Fonts.  Next File, Install New Font.  The font window will open and you will have to find the folder that you unzipped it to in the Folders box on the lower left.  Once you check the folder, the font should appear in the List of Fonts box.  Select the font and click OK.  Close the font window and you should now be able to use the font in any Windows program.